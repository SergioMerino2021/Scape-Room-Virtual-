function val_1() {
    var a = document.getElementById('val-1').value
    var b = document.getElementById('val-2').value
    if (a == 'A' && b == 'pikachu') {
        return true
    } else {
        alert('¡Inténtalo de nuevo Crack!')
        return false
    }
}